import { useState } from "react";
import { Settings, Bell, Command, User, Plus, Globe, Download, Zap, Clock } from "lucide-react";
import { SearchBar } from "./SearchBar";
import { ClockWidget } from "./ClockWidget";
import { MusicWidget } from "./MusicWidget";
import { SystemStatsWidget } from "./SystemStatsWidget";
import { BookmarkGroups } from "./BookmarkGroups";
import { SettingsPanel } from "./SettingsPanel";

const WALLPAPER_URL = "https://images.unsplash.com/photo-1766329888206-beb08aa581dc?w=1600&h=900&fit=crop&auto=format";

type DashboardFrame = "default" | "search" | "settings" | "music-idle" | "sys-error";

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

const QUICK_ACTIONS = [
  { label: "New Tab", icon: Plus },
  { label: "Downloads", icon: Download },
  { label: "Translate", icon: Globe },
  { label: "Focus", icon: Zap },
  { label: "History", icon: Clock },
];

function StatsPill() {
  return (
    <div
      className="flex items-center gap-3 px-3 py-1.5 rounded-full"
      style={{
        background: "rgba(255,255,255,0.05)",
        border: "1px solid rgba(255,255,255,0.08)",
        backdropFilter: "blur(12px)",
        boxShadow: "inset 0 1px 0 rgba(255,255,255,0.06)",
      }}
    >
      <SystemStatsWidget compact />
    </div>
  );
}

export function DesktopDashboard({ frame = "default" }: { frame?: DashboardFrame }) {
  const [showSettings, setShowSettings] = useState(frame === "settings");

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden" style={{ background: "#080c14" }}>
      {/* Wallpaper */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${WALLPAPER_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "brightness(0.28) saturate(0.7)",
        }}
      />
      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(to bottom, rgba(8,12,20,0.72) 0%, rgba(8,12,20,0.32) 45%, rgba(8,12,20,0.82) 100%)",
        }}
      />

      <div className="relative z-10 flex flex-col h-full">
        {/* ── Top bar ── */}
        <div
          className="flex-shrink-0 flex items-center justify-between px-6 py-3"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.035)" }}
        >
          {/* Left: clock + stats pill */}
          <div className="flex items-center gap-4">
            <ClockWidget compact />
            <div className="h-3 w-px" style={{ background: "rgba(255,255,255,0.07)" }} />
            <StatsPill />
          </div>

          {/* Right: actions */}
          <div className="flex items-center gap-1">
            <button
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs transition-all hover:bg-white/5"
              style={{
                color: "#64748b",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
              aria-label="Command palette"
            >
              <Command size={11} style={{ color: "#64748b" }} />
              <span style={{ fontFamily: "Geist Mono, monospace", fontSize: "9px", color: "#475569" }}>K</span>
            </button>
            <button
              className="p-2 rounded-xl hover:bg-white/5 transition-all relative"
              style={{ color: "#475569" }}
              aria-label="Notifications"
            >
              <Bell size={14} />
              <div className="absolute top-1.5 right-1.5 size-1 rounded-full" style={{ background: "#8b5cf6", boxShadow: "0 0 4px #8b5cf690" }} />
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 rounded-xl hover:bg-white/5 transition-all"
              style={{ color: "#475569" }}
              aria-label="Settings"
            >
              <Settings size={14} />
            </button>
            <div
              className="size-7 rounded-full flex items-center justify-center ml-1 cursor-pointer"
              style={{
                background: "linear-gradient(135deg, #7c3aed, #0e7490)",
                boxShadow: "0 0 0 2px rgba(139,92,246,0.25), 0 2px 8px rgba(0,0,0,0.4)",
              }}
            >
              <User size={12} style={{ color: "#fff" }} />
            </div>
          </div>
        </div>

        {/* ── Body ── */}
        <div className="flex-1 flex overflow-hidden min-h-0">

          {/* Center column — biased 40px above true center */}
          <div
            className="flex-1 flex flex-col items-center justify-center min-w-0"
            style={{ paddingLeft: "32px", paddingRight: "32px", paddingBottom: "80px" }}
          >
            <div className="flex flex-col items-center gap-6 w-full" style={{ maxWidth: "672px" }}>

              {/* Greeting */}
              <div className="text-center">
                <div
                  style={{
                    color: "#f1f5f9",
                    fontSize: "32px",
                    fontWeight: 300,
                    letterSpacing: "-0.03em",
                    lineHeight: 1,
                    fontFamily: "Inter, sans-serif",
                  }}
                >
                  {getGreeting()},{" "}
                  <span style={{ fontWeight: 600 }}>Alex</span>
                </div>
                <div style={{ color: "#475569", fontSize: "12px", marginTop: "7px", letterSpacing: "0.01em" }}>
                  <span style={{ color: "#9f7aea" }}>3 meetings</span>
                  <span style={{ color: "#2d3748", margin: "0 7px" }}>·</span>
                  <span style={{ color: "#38b2ac" }}>7 messages</span>
                </div>
              </div>

              {/* Search */}
              <div className="w-full">
                <SearchBar forceActive={frame === "search"} />
              </div>

              {/* Quick action chips */}
              <div className="flex items-center gap-2">
                {QUICK_ACTIONS.map(({ label, icon: Icon }) => (
                  <button
                    key={label}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      color: "#64748b",
                    }}
                    onMouseEnter={e => {
                      const el = e.currentTarget as HTMLButtonElement;
                      el.style.background = "rgba(139,92,246,0.1)";
                      el.style.color = "#c4b5fd";
                      el.style.borderColor = "rgba(139,92,246,0.22)";
                    }}
                    onMouseLeave={e => {
                      const el = e.currentTarget as HTMLButtonElement;
                      el.style.background = "rgba(255,255,255,0.05)";
                      el.style.color = "#64748b";
                      el.style.borderColor = "rgba(255,255,255,0.07)";
                    }}
                  >
                    <Icon size={11} />
                    {label}
                  </button>
                ))}
              </div>

              {/* Bookmarks */}
              <div className="w-full">
                <div className="flex items-center justify-between mb-4">
                  <span style={{ color: "#334155", fontSize: "9px", letterSpacing: "0.09em", fontFamily: "Geist Mono, monospace" }}>
                    FAVORITES
                  </span>
                  <button
                    className="p-1 rounded-lg hover:bg-white/5 transition-all"
                    style={{ color: "#334155" }}
                    aria-label="Add bookmark"
                  >
                    <Plus size={11} />
                  </button>
                </div>
                <BookmarkGroups />
              </div>
            </div>
          </div>

          {/* ── Right sidebar — floating companion cards ── */}
          <div
            className="flex flex-col gap-3 flex-shrink-0 overflow-y-auto"
            style={{ width: "276px", padding: "20px 16px 20px 8px" }}
          >
            <div
              style={{
                color: "#334155",
                fontSize: "9px",
                letterSpacing: "0.09em",
                fontFamily: "Geist Mono, monospace",
                marginBottom: "4px",
                paddingLeft: "4px",
              }}
            >
              TODAY
            </div>

            <ClockWidget />
            <MusicWidget state={frame === "music-idle" ? "idle" : "playing"} />
            <SystemStatsWidget state={frame === "sys-error" ? "error" : "live"} />
          </div>
        </div>
      </div>

      {/* Settings overlay */}
      {showSettings && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center p-8"
          style={{ background: "rgba(0,0,0,0.65)", backdropFilter: "blur(8px)" }}
          onClick={e => { if (e.target === e.currentTarget) setShowSettings(false); }}
        >
          <div className="w-full max-w-2xl" style={{ height: "560px" }}>
            <SettingsPanel onClose={() => setShowSettings(false)} />
          </div>
        </div>
      )}
    </div>
  );
}
