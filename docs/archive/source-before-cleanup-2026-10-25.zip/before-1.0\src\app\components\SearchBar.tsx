import { useEffect, useRef, useState } from "react";
import { AlertCircle, ArrowRight, ChevronDown, Globe, ImageIcon, Loader2, Mic, Search, Sparkles, X } from "lucide-react";

declare const chrome: any;

type EngineId = "google" | "bing" | "duckduckgo" | "perplexity";
type Mode = "web" | "images" | "videos" | "news" | "ai";
type SuggestionStatus = "idle" | "loading" | "ready" | "error";
type Engine = { id: EngineId; label: string; icon: string; buildUrl: (query: string, mode: Mode) => string };
type SearchSuggestion = { text: string; detail: string; kind: "search" | "ai" };
type CacheEntry = { suggestions: SearchSuggestion[]; expiresAt: number };

const ENGINES: Engine[] = [
  {
    id: "google",
    label: "Google",
    icon: "G",
    buildUrl: (query, mode) => {
      const modeParams: Record<Mode, string> = { web: "", images: "&tbm=isch", videos: "&tbm=vid", news: "&tbm=nws", ai: "&udm=50" };
      return `https://www.google.com/search?q=${encodeURIComponent(query)}${modeParams[mode]}`;
    },
  },
  {
    id: "bing",
    label: "Bing",
    icon: "B",
    buildUrl: (query, mode) => {
      const modeParams: Record<Mode, string> = { web: "", images: "&scope=images", videos: "&scope=video", news: "&scope=news", ai: "" };
      return `https://www.bing.com/search?q=${encodeURIComponent(query)}${modeParams[mode]}`;
    },
  },
  {
    id: "duckduckgo",
    label: "DuckDuckGo",
    icon: "D",
    buildUrl: (query, mode) => {
      const modeParams: Record<Mode, string> = { web: "", images: "&iax=images&ia=images", videos: "&iax=videos&ia=videos", news: "&iar=news&ia=news", ai: "" };
      return `https://duckduckgo.com/?q=${encodeURIComponent(query)}${modeParams[mode]}`;
    },
  },
  {
    id: "perplexity",
    label: "Perplexity",
    icon: "P",
    buildUrl: (query) => `https://www.perplexity.ai/search?q=${encodeURIComponent(query)}`,
  },
];

const MODES: { id: Mode; label: string }[] = [
  { id: "web", label: "Web" },
  { id: "images", label: "Images" },
  { id: "videos", label: "Videos" },
  { id: "news", label: "News" },
  { id: "ai", label: "AI" },
];

const CACHE_MS = 90_000;
const DEBOUNCE_MS = 180;
const MIN_QUERY_LENGTH = 2;

interface SearchBarProps {
  forceActive?: boolean;
}

function normalizeSuggestions(values: unknown[], query: string, engine: Engine, mode: Mode): SearchSuggestion[] {
  const seen = new Set<string>();
  const lowerQuery = query.toLowerCase();
  return values
    .map((value) => String(value || "").replace(/\s+/g, " ").trim())
    .filter((text) => {
      const key = text.toLowerCase();
      if (!text || key === lowerQuery || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 10)
    .map((text) => ({
      text,
      kind: mode === "ai" ? "ai" : "search",
      detail: `Search ${engine.label}${mode === "web" ? "" : ` ${MODES.find((item) => item.id === mode)?.label || "Web"}`}`,
    }));
}

async function requestSuggestions(query: string, engine: EngineId, mode: Mode, signal: AbortSignal) {
  const chromeApi = typeof chrome === "undefined" ? undefined : chrome;
  const canUseExtensionProxy = Boolean(chromeApi?.runtime?.sendMessage);
  if (canUseExtensionProxy) {
    return requestExtensionSuggestions(query, engine, mode, chromeApi);
  }

  const params = new URLSearchParams({ q: query, engine, mode });
  try {
    const response = await fetch(`/api/suggest?${params.toString()}`, { signal });
    const data = await response.json();
    if (!response.ok) throw new Error(data?.error || "Suggestion service unavailable");
    return Array.isArray(data?.suggestions) ? data.suggestions : [];
  } catch (error) {
    if (signal.aborted) throw error;
    if (!chromeApi?.runtime?.sendMessage) throw error;

    return requestExtensionSuggestions(query, engine, mode, chromeApi);
  }
}

function requestExtensionSuggestions(query: string, engine: EngineId, mode: Mode, chromeApi: any) {
  return new Promise<unknown[]>((resolve, reject) => {
    chromeApi.runtime.sendMessage({ type: "GET_SEARCH_SUGGESTIONS", query, engine, mode }, (response: any) => {
      const runtimeError = chromeApi.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message || "Suggestion service unavailable"));
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error || "Suggestion service unavailable"));
        return;
      }
      resolve(Array.isArray(response.suggestions) ? response.suggestions : []);
    });
  });
}

function openUrl(url: string) {
  window.location.href = url;
}

export function SearchBar({ forceActive = false }: SearchBarProps) {
  const [query, setQuery] = useState(forceActive ? "figma" : "");
  const [focused, setFocused] = useState(forceActive);
  const [engine, setEngine] = useState(ENGINES[0]);
  const [mode, setMode] = useState<Mode>("web");
  const [showEngines, setShowEngines] = useState(false);
  const [listening, setListening] = useState(false);
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [suggestionStatus, setSuggestionStatus] = useState<SuggestionStatus>("idle");
  const [suggestionError, setSuggestionError] = useState("");
  const [activeSuggestion, setActiveSuggestion] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const cacheRef = useRef<Map<string, CacheEntry>>(new Map());
  const trimmedQuery = query.trim();
  const open = focused || forceActive;
  const showSuggestions = open && Boolean(trimmedQuery) && (suggestions.length > 0 || suggestionStatus === "loading" || suggestionStatus === "error");

  useEffect(() => {
    if (forceActive) inputRef.current?.focus();
  }, [forceActive]);

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setFocused(false);
        setShowEngines(false);
      }
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, []);

  useEffect(() => {
    setActiveSuggestion(0);
    setSuggestionError("");

    if (trimmedQuery.length < MIN_QUERY_LENGTH) {
      setSuggestions([]);
      setSuggestionStatus(trimmedQuery ? "ready" : "idle");
      return;
    }

    const cacheKey = `${engine.id}:${mode}:${trimmedQuery.toLowerCase()}`;
    const cached = cacheRef.current.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      setSuggestions(cached.suggestions);
      setSuggestionStatus("ready");
      return;
    }

    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setSuggestionStatus("loading");
      try {
        const values = await requestSuggestions(trimmedQuery, engine.id, mode, controller.signal);
        const nextSuggestions = normalizeSuggestions(values, trimmedQuery, engine, mode);
        cacheRef.current.set(cacheKey, { suggestions: nextSuggestions, expiresAt: Date.now() + CACHE_MS });
        setSuggestions(nextSuggestions);
        setSuggestionStatus("ready");
      } catch (error) {
        if (controller.signal.aborted) return;
        setSuggestions([]);
        setSuggestionStatus("error");
        setSuggestionError(error instanceof Error ? error.message : "Suggestion service unavailable");
      }
    }, DEBOUNCE_MS);

    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [engine, mode, trimmedQuery]);

  function runSearch(value = query) {
    const trimmed = value.trim();
    if (!trimmed) return;
    openUrl(engine.buildUrl(trimmed, mode));
  }

  function chooseSuggestion(text: string) {
    setQuery(text);
    setFocused(false);
    runSearch(text);
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Escape") {
      setFocused(false);
      setShowEngines(false);
      return;
    }
    if (!suggestions.length) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveSuggestion((current) => (current + 1) % suggestions.length);
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveSuggestion((current) => (current - 1 + suggestions.length) % suggestions.length);
    }
  }

  return (
    <div ref={wrapRef} className="w-full max-w-2xl mx-auto" style={{ position: "relative" }}>
      <div className="flex items-center justify-center gap-1 mb-4">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className="px-3.5 py-1 rounded-full text-xs transition-all"
            style={{
              background: mode === m.id ? "rgba(139,92,246,0.16)" : "transparent",
              color: mode === m.id ? "#c4b5fd" : "#64748b",
              border: `1px solid ${mode === m.id ? "rgba(139,92,246,0.3)" : "transparent"}`,
            }}
          >
            {m.label}
          </button>
        ))}
      </div>

      <form
        className="relative flex items-center rounded-2xl transition-all duration-300"
        style={{
          background: open ? "rgba(12, 18, 40, 0.82)" : "rgba(12, 18, 36, 0.65)",
          border: `1px solid ${open ? "rgba(139,92,246,0.45)" : "rgba(255,255,255,0.07)"}`,
          boxShadow: open ? "0 0 0 4px rgba(139,92,246,0.08), 0 16px 48px rgba(0,0,0,0.45)" : "0 4px 24px rgba(0,0,0,0.3)",
          backdropFilter: "blur(20px)",
        }}
        onSubmit={(event) => {
          event.preventDefault();
          runSearch(query);
        }}
      >
        <div className="relative flex-shrink-0 pl-3">
          <button
            type="button"
            onClick={() => setShowEngines(!showEngines)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all"
            style={{ background: "rgba(139,92,246,0.1)", color: "#c4b5fd", border: "1px solid rgba(139,92,246,0.18)" }}
            aria-expanded={showEngines}
          >
            <Globe size={11} style={{ color: "#8b5cf6" }} />
            {engine.label}
            <ChevronDown size={9} style={{ opacity: 0.5 }} />
          </button>

          {showEngines && (
            <div
              className="absolute top-full left-0 mt-2 rounded-2xl overflow-hidden z-50 py-1.5"
              style={{
                background: "rgba(10,14,26,0.97)",
                border: "1px solid rgba(139,92,246,0.15)",
                boxShadow: "0 16px 48px rgba(0,0,0,0.6)",
                backdropFilter: "blur(20px)",
                minWidth: "160px",
              }}
            >
              {ENGINES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setEngine(item);
                    setShowEngines(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-xs text-left transition-all hover:bg-white/5"
                  style={{ color: item.id === engine.id ? "#c4b5fd" : "#94a3b8" }}
                >
                  <span
                    className="size-5 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{
                      background: item.id === engine.id ? "rgba(139,92,246,0.15)" : "rgba(255,255,255,0.04)",
                      fontFamily: "Geist Mono, monospace",
                      fontSize: "9px",
                      fontWeight: 700,
                      color: item.id === engine.id ? "#8b5cf6" : "#64748b",
                    }}
                  >
                    {item.icon}
                  </span>
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <Search size={18} style={{ color: "#64748b", marginLeft: "10px", flex: "0 0 auto" }} />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setFocused(true);
          }}
          onFocus={() => setFocused(true)}
          onKeyDown={handleKeyDown}
          placeholder={mode === "ai" ? `Ask ${engine.label} AI` : `Search ${engine.label} or enter a URL`}
          className="flex-1 bg-transparent py-4 px-3 text-sm outline-none"
          style={{ color: "#e2e8f0", fontFamily: "Inter, sans-serif" }}
          role="combobox"
          aria-expanded={showSuggestions}
          aria-controls="searchbar-suggestions"
          aria-autocomplete="list"
          spellCheck={false}
        />

        <div className="flex items-center gap-1 pr-2">
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
              aria-label="Clear"
            >
              <X size={13} style={{ color: "#64748b" }} />
            </button>
          )}
          <button
            type="button"
            onClick={() => setListening(!listening)}
            className="p-2 rounded-xl transition-all"
            style={{ color: listening ? "#22d3ee" : "#64748b", background: listening ? "rgba(34,211,238,0.1)" : "transparent" }}
            aria-label="Voice search"
          >
            <Mic size={15} />
          </button>
          <button type="button" className="p-2 rounded-xl hover:bg-white/5 transition-colors" style={{ color: "#64748b" }} aria-label="Image search">
            <ImageIcon size={15} />
          </button>
          <button
            type="submit"
            className="flex items-center justify-center size-8 rounded-xl transition-all ml-0.5"
            style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)", boxShadow: "0 2px 12px rgba(124,58,237,0.4)" }}
            aria-label="Search"
          >
            <ArrowRight size={14} style={{ color: "#fff" }} />
          </button>
        </div>
      </form>

      {showSuggestions && (
        <div
          id="searchbar-suggestions"
          className="absolute left-0 right-0 mt-2 rounded-3xl overflow-hidden z-40 p-2"
          style={{
            background: "rgba(9,13,24,0.96)",
            border: "1px solid rgba(139,92,246,0.12)",
            boxShadow: "0 20px 60px rgba(0,0,0,0.55)",
            backdropFilter: "blur(24px)",
            maxHeight: "min(56vh, 508px)",
            overflowY: "auto",
          }}
          role="listbox"
        >
          {suggestionStatus === "loading" && (
            <div className="flex items-center gap-3 px-4 py-3 text-sm" style={{ color: "#64748b" }} role="status">
              <Loader2 size={15} className="animate-spin" />
              Fetching suggestions from {engine.label}
            </div>
          )}
          {suggestionStatus === "error" && (
            <div className="flex items-center gap-3 px-4 py-3 text-sm" style={{ color: "#fb7185" }} role="status">
              <AlertCircle size={15} />
              {suggestionError || "Suggestion service unavailable"}
            </div>
          )}
          {suggestions.map((suggestion, index) => (
            <button
              key={`${suggestion.text}-${index}`}
              type="button"
              role="option"
              aria-selected={activeSuggestion === index}
              onMouseEnter={() => setActiveSuggestion(index)}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => chooseSuggestion(suggestion.text)}
              className="w-full grid items-center gap-3 px-3 text-sm text-left transition-colors"
              style={{
                gridTemplateColumns: "30px minmax(0, 1fr) 20px",
                minHeight: "44px",
                borderRadius: "14px",
                background: activeSuggestion === index ? "rgba(139,92,246,0.14)" : "transparent",
                color: "#cbd5e1",
              }}
            >
              <span className="size-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ color: suggestion.kind === "ai" ? "#d8ccff" : "#94a3b8" }}>
                {suggestion.kind === "ai" ? <Sparkles size={15} /> : <Search size={15} />}
              </span>
              <span className="min-w-0">
                <strong className="block truncate" style={{ color: "#eef5ff", fontSize: "14px", fontWeight: 650 }}>{suggestion.text}</strong>
                <small className="block truncate" style={{ color: "#64748b", fontSize: "11px", marginTop: "1px" }}>{suggestion.detail}</small>
              </span>
              <ArrowRight size={12} style={{ color: "#64748b", opacity: activeSuggestion === index ? 0.85 : 0.25 }} />
            </button>
          ))}
        </div>
      )}

      {listening && (
        <div className="absolute -bottom-8 inset-x-0 flex items-center justify-center gap-1.5" style={{ color: "#22d3ee", fontSize: "11px" }}>
          {[4, 7, 10, 7, 4, 9, 6].map((h, i) => (
            <div key={i} className="w-0.5 rounded-full" style={{ background: "#22d3ee", height: `${h}px`, animation: `vb ${0.4 + i * 0.08}s ease-in-out infinite alternate`, animationDelay: `${i * 0.06}s` }} />
          ))}
          <span className="ml-2">Listening...</span>
        </div>
      )}
      <style>{`@keyframes vb{from{height:3px}to{height:14px}}`}</style>
    </div>
  );
}
