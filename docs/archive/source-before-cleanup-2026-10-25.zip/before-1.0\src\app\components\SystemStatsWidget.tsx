import { useState, useEffect } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

function PulseBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <span style={{ color: "#64748b", fontSize: "9px", fontFamily: "Geist Mono, monospace", minWidth: "28px", letterSpacing: "0.04em" }}>{label}</span>
      <div className="flex-1 h-0.5 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }}>
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value}%`, background: `linear-gradient(90deg, ${color}dd, ${color}77)` }}
        />
      </div>
      <span style={{ color, fontSize: "9px", fontFamily: "Geist Mono, monospace", minWidth: "24px", textAlign: "right", opacity: 0.9 }}>{value}%</span>
    </div>
  );
}

export function SystemStatsWidget({ state = "live", compact = false }: { state?: "live" | "error"; compact?: boolean }) {
  const [stats, setStats] = useState({ cpu: 24, ram: 61, disk: 18 });

  useEffect(() => {
    if (state !== "live") return;
    const t = setInterval(() => {
      setStats(p => ({
        cpu: Math.max(5,  Math.min(90, p.cpu + (Math.random()-0.45)*8)),
        ram: Math.max(30, Math.min(88, p.ram + (Math.random()-0.5)*3)),
        disk: Math.max(0,  Math.min(100, p.disk + (Math.random()-0.5)*15)),
      }));
    }, 2400);
    return () => clearInterval(t);
  }, [state]);

  if (state === "error") {
    return (
      <div
        className="rounded-2xl p-4 flex flex-col items-center gap-2 text-center"
        style={{
          background: "rgba(12,18,36,0.72)",
          border: "1px solid rgba(244,63,94,0.18)",
          backdropFilter: "blur(16px)",
        }}
      >
        <AlertTriangle size={15} style={{ color: "#f43f5e", opacity: 0.8 }} />
        <div style={{ color: "#64748b", fontSize: "11px" }}>Monitor offline</div>
        <button
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-all"
          style={{ color: "#f43f5e", background: "rgba(244,63,94,0.08)", border: "1px solid rgba(244,63,94,0.15)" }}
        >
          <RefreshCw size={10} /> Retry
        </button>
      </div>
    );
  }

  if (compact) {
    const items = [
      { label: "CPU", value: Math.round(stats.cpu), color: "#a78bfa" },
      { label: "RAM", value: Math.round(stats.ram), color: "#22d3ee" },
      { label: "DSK", value: Math.round(stats.disk), color: "#34d399" },
    ];
    return (
      <div className="flex items-center gap-3.5">
        {items.map(({ label, value, color }) => (
          <div key={label} className="flex items-center gap-1.5">
            <div className="size-1.5 rounded-full" style={{ background: color, opacity: 0.75 }} />
            <span style={{ color: "#64748b", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>{label}</span>
            <span style={{ color, fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>{value}%</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div
      className="rounded-2xl p-4 flex flex-col gap-3"
      style={{
        background: "rgba(12,18,36,0.72)",
        border: "1px solid rgba(255,255,255,0.07)",
        backdropFilter: "blur(16px)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.05)",
      }}
    >
      <div className="flex items-center justify-between">
        <span style={{ color: "#475569", fontSize: "9px", fontFamily: "Geist Mono, monospace", letterSpacing: "0.07em" }}>SYSTEM</span>
        <div className="flex items-center gap-1.5">
          <div className="size-1 rounded-full" style={{ background: "#34d399", opacity: 0.7, animation: "pulse 2.5s ease-in-out infinite" }} />
          <span style={{ color: "#475569", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>LIVE</span>
        </div>
      </div>

      <div className="flex flex-col gap-2.5">
        <PulseBar label="CPU" value={Math.round(stats.cpu)} color="#a78bfa" />
        <PulseBar label="RAM" value={Math.round(stats.ram)} color="#22d3ee" />
        <PulseBar label="DSK" value={Math.round(stats.disk)} color="#34d399" />
      </div>
    </div>
  );
}
