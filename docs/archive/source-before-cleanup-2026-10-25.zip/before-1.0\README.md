
# PikaNav

A Chrome Manifest V3 extension that replaces the new-tab page with a customizable dashboard.

## Install a release

Extract `releases/PikaNav-0.2.0.zip`, open `chrome://extensions`, enable Developer mode, click **Load unpacked**, and choose the extracted `extension` folder. Keep that folder in place. No Node.js, local server, or companion app is needed for installation.

See [installation and media support](docs/INSTALL.md) for updates, moving settings, browser media access, and optional integrations.

## Media connector

The Music widget works independently of the companion for accessible HTML audio/video playing in Chrome tabs. Click **Enable browser media** to grant optional site access. It reads the page's Media Session metadata where available, supports play/pause, and detects previous/next buttons on supported web players. Browser sessions take priority; desktop media falls back to the optional Windows native host.

Windows desktop media and system stats still require the companion. The older extension in `pikanav-media-mvp/extension` is a native-host diagnostic tool and still requires it; it is not the portable dashboard release.

## Build and package

Requires Node.js 22.12+ and npm.

```sh
npm ci
npm run package
```

Packaging runs media tests, builds the extension, checks its manifest/icons/assets, and creates both a ready-to-load folder and a ZIP under `releases/`. The release contains only the built extension, install guide, and attributions, with no source, native binaries, dependencies, or local settings. `npm run build` creates `dist/`; `npm run dev` starts the web preview (extension integrations require loading it in Chrome).

The manifest version and package version should be updated together for releases. Google Calendar requires an OAuth client configured for the installed extension ID; see the install guide before distributing it. Public one-click installation requires Chrome Web Store publication.

## Companion development

See [the Windows native companion](pikanav-media-mvp/README.md). Its current installer builds a framework-dependent .NET 8 host on the user's machine and is not included in the portable extension package.

The original dashboard design is available [on Figma](https://www.figma.com/design/yCDgbKZjXOC3yYOOVFB6Uu/Customizable-New-Tab-Dashboard).
