import { useState, useEffect } from "react";

const DAYS   = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function pad(n: number) { return String(n).padStart(2, "0"); }

export function ClockWidget({ compact = false }: { compact?: boolean }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const h    = now.getHours();
  const m    = now.getMinutes();
  const s    = now.getSeconds();
  const ampm = h >= 12 ? "PM" : "AM";
  const h12  = h % 12 || 12;
  const day  = DAYS[now.getDay()];
  const date = `${MONTHS[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;

  if (compact) {
    return (
      <div className="flex items-baseline gap-2">
        <span style={{ fontFamily: "Geist Mono, monospace", color: "#94a3b8", fontSize: "13px", fontWeight: 500, letterSpacing: "-0.01em" }}>
          {pad(h12)}:{pad(m)}
        </span>
        <span style={{ color: "#475569", fontSize: "10px" }}>{ampm}</span>
        <span style={{ color: "#2d3748", fontSize: "10px", marginLeft: "2px" }}>·</span>
        <span style={{ color: "#64748b", fontSize: "11px" }}>{day.slice(0,3)}, {MONTHS[now.getMonth()]} {now.getDate()}</span>
      </div>
    );
  }

  return (
    <div
      className="rounded-2xl p-4 flex flex-col gap-3 relative overflow-hidden"
      style={{
        background: "rgba(12, 18, 36, 0.72)",
        border: "1px solid rgba(255,255,255,0.07)",
        backdropFilter: "blur(16px)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.05)",
      }}
    >
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: "linear-gradient(90deg, transparent, rgba(139,92,246,0.45), rgba(34,211,238,0.35), transparent)" }}
      />

      {/* Time */}
      <div className="flex items-end gap-2">
        <div
          style={{
            fontFamily: "Geist Mono, monospace",
            fontSize: "42px",
            fontWeight: 600,
            letterSpacing: "-0.04em",
            color: "#e2e8f0",
            lineHeight: 1,
          }}
        >
          {pad(h12)}:{pad(m)}
        </div>
        <div className="flex flex-col pb-0.5 gap-0.5">
          <span style={{ fontFamily: "Geist Mono, monospace", fontSize: "13px", fontWeight: 500, color: "#8b5cf6", lineHeight: 1 }}>{ampm}</span>
          <span style={{ fontFamily: "Geist Mono, monospace", fontSize: "10px", color: "#334155" }}>:{pad(s)}</span>
        </div>
      </div>

      {/* Day + date */}
      <div>
        <div style={{ color: "#94a3b8", fontSize: "12px", fontWeight: 500 }}>{day}</div>
        <div style={{ color: "#475569", fontSize: "11px" }}>{date}</div>
      </div>

      {/* World clock strip */}
      <div
        className="flex items-center gap-3 pt-2"
        style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
      >
        {[
          { city: "NY",  offset: -4 },
          { city: "LON", offset: +1 },
          { city: "TK",  offset: +9 },
        ].map(({ city, offset }) => {
          const t = new Date(now.getTime() + (offset - (-new Date().getTimezoneOffset()/60)) * 3600000);
          const th = t.getHours() % 12 || 12;
          const tm = t.getMinutes();
          const ta = t.getHours() >= 12 ? "PM" : "AM";
          return (
            <div key={city} className="flex items-baseline gap-1">
              <span style={{ color: "#475569", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>{city}</span>
              <span style={{ color: "#64748b", fontSize: "10px", fontFamily: "Geist Mono, monospace" }}>{pad(th)}:{pad(tm)}</span>
              <span style={{ color: "#334155", fontSize: "8px" }}>{ta}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
