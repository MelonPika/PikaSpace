import { useState } from "react";
import { Plus, MoreHorizontal } from "lucide-react";

interface Bookmark {
  id: string;
  title: string;
  url: string;
  emoji: string;
  color: string;
  pinned?: boolean;
}

interface Group {
  id: string;
  name: string;
  bookmarks: Bookmark[];
}

const GROUPS: Group[] = [
  {
    id: "pinned",
    name: "Pinned",
    bookmarks: [
      { id: "b1",  title: "GitHub",     url: "github.com",              emoji: "🐙", color: "#6e40c9", pinned: true },
      { id: "b2",  title: "Figma",      url: "figma.com",               emoji: "🎨", color: "#8b5cf6", pinned: true },
      { id: "b3",  title: "Linear",     url: "linear.app",              emoji: "📐", color: "#5b6af5", pinned: true },
      { id: "b4",  title: "Notion",     url: "notion.so",               emoji: "📝", color: "#64748b", pinned: true },
      { id: "b5",  title: "Vercel",     url: "vercel.com",              emoji: "▲",  color: "#94a3b8", pinned: true },
      { id: "b6",  title: "Raycast",    url: "raycast.com",             emoji: "🔮", color: "#e8472a", pinned: true },
      { id: "b7",  title: "Supabase",   url: "supabase.com",            emoji: "⚡", color: "#22c55e", pinned: true },
      { id: "b8",  title: "Tailwind",   url: "tailwindcss.com",         emoji: "💨", color: "#22d3ee", pinned: true },
    ],
  },
  {
    id: "dev",
    name: "Dev",
    bookmarks: [
      { id: "b9",  title: "MDN",        url: "developer.mozilla.org",   emoji: "📚", color: "#3b82f6" },
      { id: "b10", title: "Can I Use",  url: "caniuse.com",             emoji: "✅", color: "#22c55e" },
      { id: "b11", title: "npm",        url: "npmjs.com",               emoji: "📦", color: "#f87171" },
      { id: "b12", title: "DevDocs",    url: "devdocs.io",              emoji: "📖", color: "#94a3b8" },
      { id: "b13", title: "Bundlephobia", url: "bundlephobia.com",      emoji: "⚖️", color: "#a78bfa" },
    ],
  },
  {
    id: "reading",
    name: "Reading",
    bookmarks: [
      { id: "b14", title: "HN",         url: "news.ycombinator.com",    emoji: "🔥", color: "#fb923c" },
      { id: "b15", title: "The Verge",  url: "theverge.com",            emoji: "📡", color: "#f87171" },
      { id: "b16", title: "Lobsters",   url: "lobste.rs",               emoji: "🦞", color: "#fda4af" },
    ],
  },
];

function BookmarkTile({ bm, color }: { bm: Bookmark; color: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex flex-col items-center gap-2.5 group"
      title={bm.url}
      style={{ width: "68px" }}
    >
      <div
        className="size-12 rounded-2xl flex items-center justify-center relative overflow-hidden"
        style={{
          background: hovered
            ? `linear-gradient(135deg, ${color}22, ${color}12)`
            : "rgba(255,255,255,0.07)",
          border: `1px solid ${hovered ? `${color}50` : "rgba(255,255,255,0.10)"}`,
          boxShadow: hovered
            ? `0 0 0 3px ${color}18, 0 8px 28px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.10)`
            : "0 2px 8px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.07)",
          transform: hovered ? "translateY(-3px) scale(1.04)" : "translateY(0) scale(1)",
          transition: "all 0.18s cubic-bezier(0.34, 1.56, 0.64, 1)",
          backdropFilter: "blur(10px)",
          fontSize: "21px",
          lineHeight: 1,
        }}
      >
        {bm.emoji}
        {bm.pinned && (
          <div
            className="absolute top-1 right-1 size-1.5 rounded-full"
            style={{ background: `${color}cc`, boxShadow: `0 0 4px ${color}80` }}
          />
        )}
      </div>
      <span
        className="truncate w-full text-center"
        style={{
          color: hovered ? "#e2e8f0" : "#64748b",
          fontSize: "10px",
          maxWidth: "64px",
          transition: "color 0.15s",
          letterSpacing: "0.01em",
        }}
      >
        {bm.title}
      </span>
    </button>
  );
}

function AddTile() {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex flex-col items-center gap-2.5"
      style={{ width: "68px" }}
      aria-label="Add bookmark"
    >
      <div
        className="size-12 rounded-2xl flex items-center justify-center"
        style={{
          background: hovered ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.04)",
          border: `1.5px dashed ${hovered ? "rgba(139,92,246,0.4)" : "rgba(255,255,255,0.10)"}`,
          boxShadow: hovered
            ? "0 4px 16px rgba(139,92,246,0.12), inset 0 1px 0 rgba(255,255,255,0.06)"
            : "0 2px 8px rgba(0,0,0,0.15)",
          transform: hovered ? "translateY(-2px)" : "translateY(0)",
          transition: "all 0.18s ease",
          backdropFilter: "blur(8px)",
          color: hovered ? "#a78bfa" : "#334155",
        }}
      >
        <Plus size={15} strokeWidth={1.5} />
      </div>
      <span
        style={{
          color: hovered ? "#7c3aed" : "#334155",
          fontSize: "10px",
          transition: "color 0.15s",
          letterSpacing: "0.01em",
        }}
      >
        Add
      </span>
    </button>
  );
}

export function BookmarkGroups({ compact = false }: { compact?: boolean }) {
  const [activeGroup, setActiveGroup] = useState("pinned");

  const group = GROUPS.find(g => g.id === activeGroup)!;

  if (compact) {
    return (
      <div className="flex flex-wrap gap-2">
        {GROUPS[0].bookmarks.slice(0, 6).map(bm => (
          <button
            key={bm.id}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs transition-all"
            style={{
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.08)",
              color: "#94a3b8",
            }}
            onMouseEnter={e => {
              const el = e.currentTarget as HTMLButtonElement;
              el.style.background = "rgba(139,92,246,0.1)";
              el.style.color = "#c4b5fd";
              el.style.borderColor = "rgba(139,92,246,0.2)";
            }}
            onMouseLeave={e => {
              const el = e.currentTarget as HTMLButtonElement;
              el.style.background = "rgba(255,255,255,0.05)";
              el.style.color = "#94a3b8";
              el.style.borderColor = "rgba(255,255,255,0.08)";
            }}
          >
            <span style={{ fontSize: "13px" }}>{bm.emoji}</span>
            {bm.title}
          </button>
        ))}
        <button
          className="px-2.5 py-1.5 rounded-xl text-xs transition-all"
          style={{ color: "#475569", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
        >
          <Plus size={12} />
        </button>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Group tabs */}
      <div className="flex items-center gap-1 mb-5">
        {GROUPS.map(g => (
          <button
            key={g.id}
            onClick={() => setActiveGroup(g.id)}
            className="px-3 py-1.5 rounded-xl text-xs font-medium transition-all"
            style={{
              background: activeGroup === g.id ? "rgba(139,92,246,0.14)" : "transparent",
              color: activeGroup === g.id ? "#c4b5fd" : "#64748b",
              border: `1px solid ${activeGroup === g.id ? "rgba(139,92,246,0.25)" : "transparent"}`,
            }}
          >
            {g.name}
            <span
              className="ml-1.5 px-1.5 py-0.5 rounded-md"
              style={{
                background: "rgba(255,255,255,0.06)",
                color: activeGroup === g.id ? "#a78bfa" : "#475569",
                fontSize: "9px",
                fontFamily: "Geist Mono, monospace",
              }}
            >
              {g.bookmarks.length}
            </span>
          </button>
        ))}
        <div className="flex items-center gap-1 ml-auto">
          <button className="p-1.5 rounded-xl hover:bg-white/5 transition-all" style={{ color: "#475569" }} aria-label="More">
            <MoreHorizontal size={13} />
          </button>
        </div>
      </div>

      {/* Tiles */}
      <div className="flex flex-wrap gap-3">
        {group.bookmarks.map(bm => (
          <BookmarkTile key={bm.id} bm={bm} color={bm.color} />
        ))}
        <AddTile />
      </div>
    </div>
  );
}
