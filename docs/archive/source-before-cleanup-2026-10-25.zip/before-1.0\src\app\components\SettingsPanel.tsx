import { useState } from "react";
import {
  X, Palette, Image, LayoutGrid, Puzzle, Globe, Download,
  Upload, Trash2, Check, ChevronRight, Sun, Moon, Monitor,
  Type, Sliders, Shield, RotateCcw, AlertCircle
} from "lucide-react";

type SettingsTab = "appearance" | "wallpaper" | "layout" | "widgets" | "language" | "data";

const TABS: { id: SettingsTab; label: string; Icon: React.ElementType }[] = [
  { id: "appearance", label: "Appearance", Icon: Palette },
  { id: "wallpaper", label: "Wallpaper", Icon: Image },
  { id: "layout", label: "Layout", Icon: LayoutGrid },
  { id: "widgets", label: "Widgets", Icon: Puzzle },
  { id: "language", label: "Language", Icon: Globe },
  { id: "data", label: "Data & Backup", Icon: Download },
];

const WALLPAPERS = [
  { id: "aurora", label: "Aurora", url: "https://images.unsplash.com/photo-1766329888206-beb08aa581dc?w=400&h=250&fit=crop&auto=format", active: true },
  { id: "cosmos", label: "Cosmos", url: "https://images.unsplash.com/photo-1614852206732-6728910dc175?w=400&h=250&fit=crop&auto=format", active: false },
  { id: "mountain", label: "Mountain", url: "https://images.unsplash.com/photo-1670702146868-bc7797ef47a5?w=400&h=250&fit=crop&auto=format", active: false },
  { id: "abstract", label: "Abstract", url: "https://images.unsplash.com/photo-1566410824233-a8011929225c?w=400&h=250&fit=crop&auto=format", active: false },
  { id: "solid-dark", label: "Solid Dark", url: "", active: false },
  { id: "gradient", label: "Gradient", url: "", active: false },
];

const THEMES = [
  { id: "default", label: "Nebula", primary: "#6366f1", active: true },
  { id: "cyan", label: "Teal", primary: "#14b8a6", active: false },
  { id: "amber", label: "Amber", primary: "#f59e0b", active: false },
  { id: "rose", label: "Rose", primary: "#f43f5e", active: false },
  { id: "emerald", label: "Emerald", primary: "#10b981", active: false },
  { id: "custom", label: "Custom", primary: "linear-gradient(135deg,#ff6b6b,#a855f7)", active: false },
];

const LANGUAGES = [
  { code: "en-US", label: "English (US)", native: "English" },
  { code: "en-GB", label: "English (UK)", native: "English" },
  { code: "fr-FR", label: "French", native: "Français" },
  { code: "de-DE", label: "German", native: "Deutsch" },
  { code: "ja-JP", label: "Japanese", native: "日本語" },
  { code: "zh-CN", label: "Chinese (Simplified)", native: "中文" },
];

const WIDGETS_CONFIG = [
  { id: "clock", label: "Clock & Date", enabled: true, description: "Digital clock with timezone support" },
  { id: "music", label: "Music Player", enabled: true, description: "Spotify, Apple Music, or local player" },
  { id: "system", label: "System Monitor", enabled: true, description: "CPU, RAM, disk, GPU stats" },
  { id: "weather", label: "Weather", enabled: false, description: "Current conditions and 5-day forecast" },
  { id: "notes", label: "Quick Notes", enabled: false, description: "Sticky notes and reminders" },
  { id: "tasks", label: "Task List", enabled: false, description: "Integrated to-do list" },
  { id: "calendar", label: "Calendar", enabled: false, description: "Upcoming events widget" },
  { id: "news", label: "News Feed", enabled: false, description: "Curated articles by topic" },
];

function ToggleRow({ label, defaultOn }: { label: string; defaultOn: boolean }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <div className="flex items-center justify-between py-1.5">
      <span style={{ color: "#475569", fontSize: "12px" }}>{label}</span>
      <Toggle enabled={on} onChange={setOn} />
    </div>
  );
}

function Toggle({ enabled, onChange }: { enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={enabled}
      onClick={() => onChange(!enabled)}
      className="w-9 h-5 rounded-full relative transition-all flex-shrink-0"
      style={{ background: enabled ? "#7c3aed" : "rgba(255,255,255,0.10)" }}
    >
      <div
        className="absolute top-0.5 size-4 rounded-full transition-all"
        style={{ background: enabled ? "#e9d5ff" : "#334155", left: enabled ? "calc(100% - 18px)" : "2px" }}
      />
    </button>
  );
}

function SliderInput({ label, value, min, max, unit = "%", onChange }: {
  label: string; value: number; min: number; max: number; unit?: string; onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      <span style={{ color: "#475569", fontSize: "12px", minWidth: "100px" }}>{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="flex-1 h-1 rounded-full appearance-none cursor-pointer"
        style={{ accentColor: "#8b5cf6" }}
      />
      <span style={{ color: "#475569", fontSize: "11px", fontFamily: "Geist Mono, monospace", minWidth: "32px", textAlign: "right" }}>
        {value}{unit}
      </span>
    </div>
  );
}

interface SettingsPanelProps {
  onClose?: () => void;
}

export function SettingsPanel({ onClose }: SettingsPanelProps) {
  const [tab, setTab] = useState<SettingsTab>("appearance");
  const [themeMode, setThemeMode] = useState<"dark" | "light" | "auto">("dark");
  const [activeTheme, setActiveTheme] = useState("default");
  const [wallpaper, setWallpaper] = useState("aurora");
  const [wallpaperBlur, setWallpaperBlur] = useState(0);
  const [wallpaperDim, setWallpaperDim] = useState(40);
  const [language, setLanguage] = useState("en-US");
  const [fontSize, setFontSize] = useState(16);
  const [widgetOpacity, setWidgetOpacity] = useState(88);
  const [widgets, setWidgets] = useState(WIDGETS_CONFIG);
  const [layout, setLayout] = useState<"comfortable" | "compact" | "spacious">("comfortable");
  const [searchPosition, setSearchPosition] = useState<"center" | "top" | "bottom">("center");
  const [showDataWarning, setShowDataWarning] = useState(false);

  const toggleWidget = (id: string) => {
    setWidgets((ws) => ws.map((w) => w.id === id ? { ...w, enabled: !w.enabled } : w));
  };

  return (
    <div
      className="flex h-full rounded-2xl overflow-hidden"
      style={{
        background: "rgba(8,12,20,0.97)",
        border: "1px solid rgba(139,92,246,0.12)",
        boxShadow: "0 24px 80px rgba(0,0,0,0.7)",
        minHeight: "520px",
        backdropFilter: "blur(24px)",
      }}
    >
      {/* Sidebar */}
      <div
        className="w-48 flex-shrink-0 flex flex-col py-4"
        style={{ borderRight: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div className="px-4 mb-4 flex items-center justify-between">
          <span style={{ color: "#e2e8f0", fontSize: "13px", fontWeight: 600, letterSpacing: "-0.01em" }}>Settings</span>
          {onClose && (
            <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/6 transition-all" aria-label="Close settings">
              <X size={14} style={{ color: "#475569" }} />
            </button>
          )}
        </div>

        <nav className="flex flex-col gap-0.5 px-2">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all text-left"
              style={{
                background: tab === id ? "rgba(139,92,246,0.12)" : "transparent",
                color: tab === id ? "#c4b5fd" : "#475569",
              }}
            >
              <Icon size={13} style={{ color: tab === id ? "#8b5cf6" : "#334155" }} />
              {label}
              {tab === id && <ChevronRight size={11} className="ml-auto" style={{ color: "#8b5cf6" }} />}
            </button>
          ))}
        </nav>

        <div className="mt-auto px-4 pt-4" style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}>
          <div style={{ color: "#1e293b", fontSize: "10px", fontFamily: "Geist Mono, monospace" }}>v2.4.1-beta</div>
          <div style={{ color: "#1e293b", fontSize: "10px" }}>PikaNav</div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5">

        {/* APPEARANCE */}
        {tab === "appearance" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Appearance</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Customize colors, typography, and theme mode.</p>
            </div>

            {/* Theme mode */}
            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>THEME MODE</label>
              <div className="flex gap-2">
                {([
                  { id: "dark", label: "Dark", Icon: Moon },
                  { id: "light", label: "Light", Icon: Sun },
                  { id: "auto", label: "Auto", Icon: Monitor },
                ] as const).map(({ id, label, Icon }) => (
                  <button
                    key={id}
                    onClick={() => setThemeMode(id)}
                    className="flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl text-xs font-medium transition-all"
                    style={{
                      background: themeMode === id ? "rgba(139,92,246,0.12)" : "rgba(255,255,255,0.04)",
                      border: `1px solid ${themeMode === id ? "rgba(139,92,246,0.3)" : "rgba(255,255,255,0.06)"}`,
                      color: themeMode === id ? "#c4b5fd" : "#475569",
                    }}
                  >
                    <Icon size={15} style={{ color: themeMode === id ? "#8b5cf6" : "#334155" }} />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Accent color */}
            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>ACCENT COLOR</label>
              <div className="grid grid-cols-6 gap-2">
                {THEMES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTheme(t.id)}
                    className="flex flex-col items-center gap-1.5 group"
                    title={t.label}
                  >
                    <div
                      className="size-8 rounded-xl relative transition-all"
                      style={{
                        background: t.primary,
                        border: activeTheme === t.id ? "2px solid rgba(255,255,255,0.8)" : "2px solid transparent",
                        boxShadow: activeTheme === t.id ? `0 0 0 3px ${t.primary}55` : "none",
                      }}
                    >
                      {activeTheme === t.id && (
                        <Check size={12} className="absolute inset-0 m-auto" style={{ color: "#fff" }} />
                      )}
                    </div>
                    <span style={{ color: "#334155", fontSize: "9px" }}>{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Typography */}
            <div className="flex flex-col gap-3">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>TYPOGRAPHY</label>
              <SliderInput label="Base font size" value={fontSize} min={12} max={20} unit="px" onChange={setFontSize} />
              <div className="flex items-center gap-3">
                <span style={{ color: "#475569", fontSize: "12px", minWidth: "100px" }}>Font family</span>
                <select
                  className="flex-1 px-3 py-1.5 rounded-lg text-xs outline-none"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.07)",
                    color: "#94a3b8",
                    fontFamily: "Inter, sans-serif",
                  }}
                >
                  <option value="inter">Inter (Default)</option>
                  <option value="dm-sans">DM Sans</option>
                  <option value="geist">Geist</option>
                  <option value="system">System UI</option>
                </select>
              </div>
            </div>

            {/* Widget opacity */}
            <div className="flex flex-col gap-3">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>WIDGET STYLE</label>
              <SliderInput label="Panel opacity" value={widgetOpacity} min={20} max={100} onChange={setWidgetOpacity} />
            </div>
          </div>
        )}

        {/* WALLPAPER */}
        {tab === "wallpaper" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Wallpaper</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Choose a background for your dashboard.</p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {WALLPAPERS.map((wp) => (
                <button
                  key={wp.id}
                  onClick={() => setWallpaper(wp.id)}
                  className="relative rounded-xl overflow-hidden transition-all"
                  style={{
                    aspectRatio: "16/10",
                    border: `2px solid ${wallpaper === wp.id ? "#8b5cf6" : "rgba(255,255,255,0.06)"}`,
                    boxShadow: wallpaper === wp.id ? "0 0 0 3px rgba(139,92,246,0.2)" : "none",
                  }}
                >
                  {wp.url ? (
                    <img src={wp.url} alt={wp.label} className="w-full h-full object-cover" />
                  ) : (
                    <div
                      className="w-full h-full"
                      style={{
                        background: wp.id === "solid-dark"
                          ? "#0c0c0f"
                          : "linear-gradient(135deg, #1a1040 0%, #0f1f2e 50%, #0c0c0f 100%)",
                      }}
                    />
                  )}
                  <div className="absolute inset-0 flex items-end p-2" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.6), transparent)" }}>
                    <span style={{ color: "#fff", fontSize: "10px", fontWeight: 500 }}>{wp.label}</span>
                  </div>
                  {wallpaper === wp.id && (
                    <div className="absolute top-1.5 right-1.5 size-4 rounded-full flex items-center justify-center" style={{ background: "#7c3aed" }}>
                      <Check size={9} style={{ color: "#fff" }} />
                    </div>
                  )}
                </button>
              ))}
            </div>

            <button
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium transition-all hover:opacity-80 w-full justify-center"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px dashed rgba(255,255,255,0.1)", color: "#6b7280" }}
            >
              <Upload size={13} /> Upload custom wallpaper
            </button>

            <div className="flex flex-col gap-3">
              <label style={{ color: "#9ca3af", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>ADJUSTMENTS</label>
              <SliderInput label="Blur" value={wallpaperBlur} min={0} max={20} unit="px" onChange={setWallpaperBlur} />
              <SliderInput label="Dim overlay" value={wallpaperDim} min={0} max={90} onChange={setWallpaperDim} />
            </div>
          </div>
        )}

        {/* LAYOUT */}
        {tab === "layout" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Layout</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Configure density, grid, and element placement.</p>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>DENSITY</label>
              <div className="flex gap-2">
                {(["compact", "comfortable", "spacious"] as const).map((l) => (
                  <button
                    key={l}
                    onClick={() => setLayout(l)}
                    className="flex-1 py-2.5 rounded-xl text-xs font-medium transition-all capitalize"
                    style={{
                      background: layout === l ? "rgba(139,92,246,0.12)" : "rgba(255,255,255,0.04)",
                      border: `1px solid ${layout === l ? "rgba(139,92,246,0.3)" : "rgba(255,255,255,0.06)"}`,
                      color: layout === l ? "#c4b5fd" : "#475569",
                    }}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>SEARCH BAR POSITION</label>
              <div className="flex gap-2">
                {(["top", "center", "bottom"] as const).map((p) => (
                  <button
                    key={p}
                    onClick={() => setSearchPosition(p)}
                    className="flex-1 py-2.5 rounded-xl text-xs font-medium transition-all capitalize"
                    style={{
                      background: searchPosition === p ? "rgba(139,92,246,0.12)" : "rgba(255,255,255,0.04)",
                      border: `1px solid ${searchPosition === p ? "rgba(139,92,246,0.3)" : "rgba(255,255,255,0.06)"}`,
                      color: searchPosition === p ? "#c4b5fd" : "#475569",
                    }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>PANEL VISIBILITY</label>
              {[
                { label: "Show greeting message", defaultOn: true },
                { label: "Show bookmark groups", defaultOn: true },
                { label: "Show widget strip", defaultOn: true },
                { label: "Show top bar stats", defaultOn: true },
                { label: "Snap widgets to grid", defaultOn: false },
                { label: "Show keyboard shortcuts", defaultOn: false },
              ].map(({ label, defaultOn }) => (
                <ToggleRow key={label} label={label} defaultOn={defaultOn} />
              ))}
            </div>
          </div>
        )}

        {/* WIDGETS */}
        {tab === "widgets" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Widgets</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Enable, disable, and configure your widgets.</p>
            </div>

            <div className="flex flex-col gap-1.5">
              {widgets.map((w) => (
                <div
                  key={w.id}
                  className="flex items-center gap-3 px-3 py-3 rounded-xl transition-all"
                  style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}
                >
                  <div className="flex-1 min-w-0">
                    <div style={{ color: "#cbd5e1", fontSize: "12px", fontWeight: 500 }}>{w.label}</div>
                    <div style={{ color: "#334155", fontSize: "10px", marginTop: "1px" }}>{w.description}</div>
                  </div>
                  <Toggle enabled={w.enabled} onChange={() => toggleWidget(w.id)} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LANGUAGE */}
        {tab === "language" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Language & Region</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Interface language, time format, and locale.</p>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>INTERFACE LANGUAGE</label>
              <div className="flex flex-col gap-1">
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all"
                    style={{
                      background: language === lang.code ? "rgba(139,92,246,0.1)" : "rgba(255,255,255,0.03)",
                      border: `1px solid ${language === lang.code ? "rgba(139,92,246,0.25)" : "rgba(255,255,255,0.05)"}`,
                    }}
                  >
                    <div
                      className="size-7 rounded-lg flex items-center justify-center text-xs flex-shrink-0"
                      style={{ background: "rgba(255,255,255,0.05)", fontFamily: "Geist Mono, monospace", color: "#475569" }}
                    >
                      {lang.code.split("-")[0].toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <div style={{ color: "#cbd5e1", fontSize: "12px" }}>{lang.label}</div>
                      <div style={{ color: "#334155", fontSize: "10px" }}>{lang.native}</div>
                    </div>
                    {language === lang.code && <Check size={13} style={{ color: "#8b5cf6", flexShrink: 0 }} />}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>REGIONAL FORMATS</label>
              {[
                { label: "Time format", options: ["12-hour", "24-hour"] },
                { label: "Date format", options: ["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"] },
                { label: "Start of week", options: ["Sunday", "Monday"] },
              ].map(({ label, options }) => (
                <div key={label} className="flex items-center gap-3">
                  <span style={{ color: "#475569", fontSize: "12px", minWidth: "100px" }}>{label}</span>
                  <select
                    className="flex-1 px-3 py-1.5 rounded-lg text-xs outline-none"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      color: "#94a3b8",
                    }}
                  >
                    {options.map((o) => <option key={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DATA & BACKUP */}
        {tab === "data" && (
          <div className="flex flex-col gap-5">
            <div>
              <h3 style={{ color: "#e2e8f0", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Data & Backup</h3>
              <p style={{ color: "#334155", fontSize: "11px" }}>Export, import, and reset your configuration.</p>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>SYNC</label>
              <div
                className="flex items-center gap-3 px-3 py-3 rounded-xl"
                style={{ background: "rgba(139,92,246,0.07)", border: "1px solid rgba(139,92,246,0.14)" }}
              >
                <Shield size={16} style={{ color: "#8b5cf6" }} />
                <div className="flex-1">
                  <div style={{ color: "#c4b5fd", fontSize: "12px", fontWeight: 500 }}>Cloud sync enabled</div>
                  <div style={{ color: "#334155", fontSize: "10px" }}>Last synced: 3 minutes ago</div>
                </div>
                <div className="size-2 rounded-full" style={{ background: "#34d399" }} />
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>EXPORT & IMPORT</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  className="flex items-center gap-2 px-4 py-3 rounded-xl text-xs font-medium justify-center transition-all hover:opacity-80"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", color: "#475569" }}
                >
                  <Download size={13} /> Export settings
                </button>
                <button
                  className="flex items-center gap-2 px-4 py-3 rounded-xl text-xs font-medium justify-center transition-all hover:opacity-80"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", color: "#475569" }}
                >
                  <Upload size={13} /> Import settings
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#475569", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>STORAGE</label>
              <div
                className="p-3 rounded-xl"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}
              >
                <div className="flex justify-between mb-2" style={{ color: "#475569", fontSize: "11px" }}>
                  <span>Used storage</span>
                  <span style={{ fontFamily: "Geist Mono, monospace" }}>4.2 / 50 MB</span>
                </div>
                <div className="h-1 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }}>
                  <div className="h-full rounded-full" style={{ width: "8.4%", background: "#8b5cf6" }} />
                </div>
                <div className="flex gap-3 mt-2.5">
                  {[
                    { label: "Bookmarks", size: "1.8 MB", color: "#6366f1" },
                    { label: "Settings", size: "0.4 MB", color: "#22d3ee" },
                    { label: "Cache", size: "2.0 MB", color: "#f59e0b" },
                  ].map(({ label, size, color }) => (
                    <div key={label} className="flex items-center gap-1.5">
                      <div className="size-1.5 rounded-full flex-shrink-0" style={{ background: color }} />
                      <span style={{ color: "#374151", fontSize: "9px" }}>{label}</span>
                      <span style={{ color: "#4b5563", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>{size}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label style={{ color: "#9ca3af", fontSize: "11px", fontWeight: 500, letterSpacing: "0.05em" }}>DANGER ZONE</label>
              {showDataWarning ? (
                <div
                  className="flex flex-col gap-3 p-3 rounded-xl"
                  style={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)" }}
                >
                  <div className="flex items-start gap-2">
                    <AlertCircle size={14} style={{ color: "#ef4444", flexShrink: 0, marginTop: "1px" }} />
                    <div style={{ color: "#fca5a5", fontSize: "11px" }}>This will permanently delete all your bookmarks, settings, and data. This cannot be undone.</div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:opacity-80"
                      style={{ background: "#ef4444", color: "#fff" }}
                      onClick={() => setShowDataWarning(false)}
                    >
                      Yes, reset everything
                    </button>
                    <button
                      className="px-3 py-1.5 rounded-lg text-xs transition-all hover:opacity-80"
                      style={{ background: "rgba(255,255,255,0.06)", color: "#9ca3af" }}
                      onClick={() => setShowDataWarning(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium justify-center transition-all hover:opacity-80"
                  style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.15)", color: "#ef4444" }}
                  onClick={() => setShowDataWarning(true)}
                >
                  <Trash2 size={13} /> Reset all data
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
