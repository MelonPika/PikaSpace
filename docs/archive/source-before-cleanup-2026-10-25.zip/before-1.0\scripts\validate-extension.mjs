import assert from "node:assert/strict";
import { readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

export async function validateExtension(directory) {
  const manifest = JSON.parse(await readFile(path.join(directory, "manifest.json"), "utf8"));
  assert.equal(manifest.manifest_version, 3);
  assert.equal(manifest.background.type, "module");
  assert.ok(manifest.permissions.includes("scripting"));
  for (const filename of [manifest.chrome_url_overrides.newtab, manifest.background.service_worker, "media.js"]) {
    assert.ok((await stat(path.join(directory, filename))).isFile(), `Missing ${filename}`);
  }
  for (const [size, filename] of Object.entries(manifest.icons)) {
    const bytes = await readFile(path.join(directory, filename));
    assert.equal(bytes.subarray(0, 8).toString("hex"), "89504e470d0a1a0a", `${filename} must be PNG`);
    assert.equal(bytes.readUInt32BE(16), Number(size));
    assert.equal(bytes.readUInt32BE(20), Number(size));
  }
  const html = await readFile(path.join(directory, "index.html"), "utf8");
  assert.ok(!/localhost|\/src\/|https?:\/\/[^"']+\.js/i.test(html), "Release must contain only bundled scripts");
  for (const match of html.matchAll(/(?:src|href)="(\.\/assets\/[^"?#]+)"/g)) {
    assert.ok((await stat(path.join(directory, match[1]))).isFile(), `Missing ${match[1]}`);
  }
  const forbidden = /^(node_modules|native-host|\.env.*|.*\.(?:pdb|pem|key|map|exe))$/i;
  async function checkFiles(folder) {
    for (const entry of await readdir(folder, { withFileTypes: true })) {
      assert.ok(!forbidden.test(entry.name), `Unexpected release file ${entry.name}`);
      if (entry.isDirectory()) await checkFiles(path.join(folder, entry.name));
    }
  }
  await checkFiles(directory);
  return manifest;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const directory = path.resolve(process.argv[2] || "dist");
  const manifest = await validateExtension(directory);
  console.log(`Validated ${manifest.name} ${manifest.version}: manifest, icons, assets, and release contents.`);
}
