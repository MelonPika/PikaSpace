import { useState } from "react";
import { Settings, Search, Music2, BarChart2, Bookmark, Home, Bell, Command } from "lucide-react";
import { SearchBar } from "./SearchBar";
import { ClockWidget } from "./ClockWidget";
import { MusicWidget } from "./MusicWidget";
import { SystemStatsWidget } from "./SystemStatsWidget";
import { BookmarkGroups } from "./BookmarkGroups";
import { SettingsPanel } from "./SettingsPanel";

const WALLPAPER_URL = "https://images.unsplash.com/photo-1766329888206-beb08aa581dc?w=600&h=1200&fit=crop&auto=format";

type MobileTab = "home" | "search" | "music" | "stats" | "bookmarks" | "settings";

function BottomTabBar({ active, onChange }: { active: MobileTab; onChange: (t: MobileTab) => void }) {
  const tabs: { id: MobileTab; Icon: React.ElementType; label: string }[] = [
    { id: "home", Icon: Home, label: "Home" },
    { id: "search", Icon: Search, label: "Search" },
    { id: "bookmarks", Icon: Bookmark, label: "Marks" },
    { id: "music", Icon: Music2, label: "Music" },
    { id: "settings", Icon: Settings, label: "Settings" },
  ];

  return (
    <div
      className="flex-shrink-0 flex items-center px-2 pb-2 pt-1"
      style={{
        background: "rgba(10,10,14,0.95)",
        borderTop: "1px solid rgba(255,255,255,0.07)",
        backdropFilter: "blur(12px)",
      }}
    >
      {tabs.map(({ id, Icon, label }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className="flex-1 flex flex-col items-center gap-1 py-2 rounded-xl transition-all"
          style={{ color: active === id ? "#8b5cf6" : "#334155" }}
          aria-label={label}
        >
          <Icon size={18} />
          <span style={{ fontSize: "9px", fontWeight: active === id ? 600 : 400, letterSpacing: "0.02em" }}>{label}</span>
          {active === id && (
            <div className="absolute bottom-1.5 size-1 rounded-full bg-[#8b5cf6]" />
          )}
        </button>
      ))}
    </div>
  );
}

export function MobileDashboard() {
  const [activeTab, setActiveTab] = useState<MobileTab>("home");

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden" style={{ background: "#0c0c0f" }}>
      {/* Wallpaper */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${WALLPAPER_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center top",
          filter: "brightness(0.3) saturate(0.7)",
        }}
      />
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(to bottom, rgba(12,12,15,0.5) 0%, rgba(12,12,15,0.85) 100%)" }}
      />

      {/* Status bar mock */}
      <div
        className="relative z-10 flex items-center justify-between px-5 pt-3 pb-1 flex-shrink-0"
        style={{ fontFamily: "Geist Mono, monospace", fontSize: "11px", color: "#6b7280" }}
      >
        <span>9:41</span>
        <div className="flex items-center gap-1">
          <div className="flex gap-0.5 items-end">
            {[3, 4, 5, 4].map((h, i) => (
              <div key={i} className="w-0.5 rounded-sm bg-current" style={{ height: `${h}px` }} />
            ))}
          </div>
          <span>●●●</span>
          <span>72%</span>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 flex flex-col overflow-hidden">

        {/* HOME */}
        {activeTab === "home" && (
          <div className="flex-1 overflow-y-auto px-4 py-2 flex flex-col gap-4">
            {/* Top row */}
            <div className="flex items-center justify-between">
              <div>
                <div style={{ color: "#f0f0f4", fontSize: "18px", fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.1 }}>
                  Good morning
                </div>
                <div style={{ color: "#4b5563", fontSize: "11px", marginTop: "2px" }}>Wednesday, June 10</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  className="p-2 rounded-xl hover:bg-white/5 transition-all relative"
                  style={{ background: "rgba(255,255,255,0.06)" }}
                  aria-label="Notifications"
                >
                  <Bell size={15} style={{ color: "#6b7280" }} />
                  <div className="absolute top-1.5 right-1.5 size-1.5 rounded-full bg-[#8b5cf6]" />
                </button>
                <button
                  onClick={() => setActiveTab("settings")}
                  className="p-2 rounded-xl hover:bg-white/5 transition-all"
                  style={{ background: "rgba(255,255,255,0.06)" }}
                  aria-label="Settings"
                >
                  <Settings size={15} style={{ color: "#6b7280" }} />
                </button>
              </div>
            </div>

            {/* Quick search tap target */}
            <button
              onClick={() => setActiveTab("search")}
              className="flex items-center gap-3 px-4 py-3 rounded-2xl w-full text-left transition-all"
              style={{
                background: "rgba(20,20,28,0.9)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <Search size={16} style={{ color: "#374151" }} />
              <span style={{ color: "#374151", fontSize: "13px" }}>Search the web…</span>
              <div
                className="ml-auto flex items-center gap-1 px-2 py-0.5 rounded-md"
                style={{ background: "rgba(255,255,255,0.05)" }}
              >
                <Command size={10} style={{ color: "#374151" }} />
                <span style={{ color: "#374151", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>K</span>
              </div>
            </button>

            {/* Clock */}
            <ClockWidget />

            {/* Bookmark quick access */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span style={{ color: "#374151", fontSize: "10px", letterSpacing: "0.06em", fontFamily: "Geist Mono, monospace" }}>BOOKMARKS</span>
                <button onClick={() => setActiveTab("bookmarks")} style={{ color: "#8b5cf6", fontSize: "10px" }}>View all</button>
              </div>
              <BookmarkGroups compact />
            </div>

            {/* Music mini */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span style={{ color: "#374151", fontSize: "10px", letterSpacing: "0.06em", fontFamily: "Geist Mono, monospace" }}>NOW PLAYING</span>
                <button onClick={() => setActiveTab("music")} style={{ color: "#8b5cf6", fontSize: "10px" }}>Expand</button>
              </div>
              <MusicWidget state="playing" />
            </div>
          </div>
        )}

        {/* SEARCH */}
        {activeTab === "search" && (
          <div className="flex-1 px-4 py-4 flex flex-col gap-4">
            <div style={{ color: "#f0f0f4", fontSize: "14px", fontWeight: 600, marginBottom: "4px" }}>Search</div>
            <SearchBar forceActive />
          </div>
        )}

        {/* BOOKMARKS */}
        {activeTab === "bookmarks" && (
          <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-4">
            <div style={{ color: "#f0f0f4", fontSize: "14px", fontWeight: 600 }}>Bookmarks</div>
            <BookmarkGroups />
          </div>
        )}

        {/* MUSIC */}
        {activeTab === "music" && (
          <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-4">
            <div style={{ color: "#f0f0f4", fontSize: "14px", fontWeight: 600 }}>Music</div>
            <MusicWidget state="playing" />
            <div style={{ color: "#374151", fontSize: "11px", textAlign: "center" }}>Connect Spotify, Apple Music, or a local player</div>
          </div>
        )}

        {/* SETTINGS */}
        {activeTab === "settings" && (
          <div className="flex-1 overflow-hidden">
            <SettingsPanel onClose={() => setActiveTab("home")} />
          </div>
        )}
      </div>

      {/* Bottom tabs */}
      <div className="relative z-10">
        <BottomTabBar active={activeTab} onChange={setActiveTab} />
      </div>
    </div>
  );
}
