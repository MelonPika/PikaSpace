import { useState } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart, Music } from "lucide-react";

interface Track { title: string; artist: string; duration: number; hue: number; }

const QUEUE: Track[] = [
  { title: "Kiara",       artist: "Bonobo",    duration: 356, hue: 260 },
  { title: "First Light", artist: "Tycho",     duration: 278, hue: 190 },
  { title: "Kiara",       artist: "Four Tet",  duration: 312, hue: 310 },
];

const VISUALIZER_BARS = [32, 54, 46, 70, 40, 88, 58, 76, 48, 64, 36, 82, 52, 68, 44, 60, 34, 72];

function fmt(s: number) { return `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`; }

interface MusicWidgetProps {
  state?: "playing" | "idle" | "empty";
}

export function MusicWidget({ state = "playing" }: MusicWidgetProps) {
  const [playing, setPlaying] = useState(state === "playing");
  const [idx, setIdx]         = useState(0);
  const [prog, setProg]       = useState(state === "playing" ? 38 : 0);
  const [liked, setLiked]     = useState(false);

  const track   = QUEUE[idx];
  const elapsed = Math.round((prog / 100) * track.duration);
  const accent  = `hsl(${track.hue}, 70%, 65%)`;
  const accentBg = `hsl(${track.hue}, 50%, 14%)`;

  if (state === "empty") {
    return (
      <div
        className="rounded-2xl p-4 flex flex-col items-center justify-center gap-3 text-center"
        style={{
          background: "rgba(12,18,36,0.7)",
          border: "1px solid rgba(255,255,255,0.06)",
          backdropFilter: "blur(16px)",
          minHeight: "130px",
        }}
      >
        <div className="size-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.04)" }}>
          <Music size={16} style={{ color: "#1e293b" }} />
        </div>
        <div style={{ color: "#334155", fontSize: "11px" }}>No source connected</div>
        <button
          className="px-3 py-1.5 rounded-xl text-xs font-medium transition-all"
          style={{ background: "rgba(139,92,246,0.1)", color: "#c4b5fd", border: "1px solid rgba(139,92,246,0.18)" }}
        >
          Connect music
        </button>
      </div>
    );
  }

  return (
    <div
      className="rounded-2xl overflow-hidden relative"
      style={{
        background: "rgba(12,18,36,0.7)",
        border: "1px solid rgba(255,255,255,0.06)",
        backdropFilter: "blur(16px)",
      }}
    >
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${accent}50, transparent)` }}
      />

      <div className="p-4">
        {/* Art + info */}
        <div className="flex items-center gap-3 mb-3.5">
          <div
            className="size-10 rounded-xl flex-shrink-0 flex items-center justify-center relative overflow-hidden"
            style={{ background: accentBg, border: `1px solid ${accent}25` }}
          >
            <Music size={14} style={{ color: accent, opacity: 0.7 }} />
            {playing && (
              <div className="absolute bottom-1 left-0 right-0 flex justify-center gap-0.5 items-end">
                {[3,5,4,6,3].map((h,i) => (
                  <div key={i} className="w-0.5 rounded-full" style={{
                    background: accent, height: `${h}px`,
                    animation: `mb${i} ${0.38+i*0.09}s ease-in-out infinite alternate`,
                    animationDelay: `${i*0.06}s`,
                  }} />
                ))}
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div style={{ color: "#cbd5e1", fontSize: "12px", fontWeight: 600 }} className="truncate">{track.title}</div>
            <div style={{ color: "#475569", fontSize: "11px" }} className="truncate">{track.artist}</div>
          </div>
          <button onClick={() => setLiked(!liked)} className="flex-shrink-0 transition-all p-1" aria-label="Like">
            <Heart size={13} style={{ color: liked ? "#f472b6" : "#1e293b", fill: liked ? "#f472b6" : "none" }} />
          </button>
        </div>

        {/* Visualizer */}
        <div
          className="relative mb-3 h-11 overflow-hidden rounded-xl"
          aria-label={playing ? "Audio visualization active" : "Audio visualization paused"}
          style={{
            background: `linear-gradient(180deg, ${accent}12, rgba(255,255,255,0.025))`,
            border: "1px solid rgba(255,255,255,0.055)",
            boxShadow: `inset 0 1px 0 rgba(255,255,255,0.04), 0 8px 24px ${accent}10`,
          }}
        >
          <div
            className="absolute inset-0 opacity-70"
            style={{
              background: `radial-gradient(circle at ${Math.max(8, Math.min(92, prog))}% 20%, ${accent}30, transparent 38%)`,
            }}
          />
          <div className="relative flex h-full items-end gap-1 px-2.5 pb-2 pt-2">
            {VISUALIZER_BARS.map((height, i) => {
              const idleHeight = Math.max(14, height * 0.36);

              return (
                <div
                  key={`${track.title}-${i}`}
                  className="flex-1 rounded-full"
                  style={{
                    minWidth: "3px",
                    height: `${playing ? height : idleHeight}%`,
                    background: `linear-gradient(180deg, ${accent}, ${accent}75)`,
                    opacity: playing ? 0.78 : 0.28,
                    transformOrigin: "bottom",
                    animation: playing
                      ? `vizPulse ${0.78 + (i % 5) * 0.11}s cubic-bezier(.45,0,.35,1) infinite alternate`
                      : "none",
                    animationDelay: `${i * -0.07}s`,
                    boxShadow: playing ? `0 0 10px ${accent}35` : "none",
                  }}
                />
              );
            })}
          </div>
        </div>

        {/* Progress */}
        <div
          className="h-0.5 rounded-full w-full cursor-pointer mb-1"
          style={{ background: "rgba(255,255,255,0.06)" }}
          onClick={e => {
            const r = e.currentTarget.getBoundingClientRect();
            setProg(((e.clientX - r.left) / r.width) * 100);
          }}
        >
          <div className="h-full rounded-full transition-all" style={{ width: `${prog}%`, background: `linear-gradient(90deg, ${accent}, ${accent}80)` }} />
        </div>
        <div className="flex justify-between mb-3" style={{ color: "#1e293b", fontSize: "9px", fontFamily: "Geist Mono, monospace" }}>
          <span>{fmt(elapsed)}</span>
          <span>{fmt(track.duration)}</span>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <button onClick={() => setIdx((idx-1+QUEUE.length)%QUEUE.length)} className="p-1 transition-all hover:opacity-70" style={{ color: "#334155" }}>
            <SkipBack size={15} />
          </button>
          <button
            onClick={() => setPlaying(!playing)}
            className="size-9 rounded-full flex items-center justify-center transition-all"
            style={{
              background: `linear-gradient(135deg, ${accent}cc, ${accent}88)`,
              boxShadow: `0 2px 12px ${accent}30`,
            }}
          >
            {playing
              ? <Pause size={14} style={{ color: "#fff" }} />
              : <Play  size={14} style={{ color: "#fff", marginLeft: "1px" }} />}
          </button>
          <button onClick={() => setIdx((idx+1)%QUEUE.length)} className="p-1 transition-all hover:opacity-70" style={{ color: "#334155" }}>
            <SkipForward size={15} />
          </button>
        </div>
      </div>

      <style>{`
        @keyframes mb0{from{height:3px}to{height:7px}}
        @keyframes mb1{from{height:5px}to{height:10px}}
        @keyframes mb2{from{height:4px}to{height:8px}}
        @keyframes mb3{from{height:6px}to{height:12px}}
        @keyframes mb4{from{height:3px}to{height:6px}}
        @keyframes vizPulse{
          from{transform:scaleY(.42)}
          50%{transform:scaleY(1)}
          to{transform:scaleY(.68)}
        }
      `}</style>
    </div>
  );
}
