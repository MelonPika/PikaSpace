# Install PikaNav

1. Extract the PikaNav ZIP to a permanent folder on your computer.
2. Open `chrome://extensions` in desktop Google Chrome.
3. Enable **Developer mode**, then choose **Load unpacked**.
4. Select the extracted **extension** folder (the one containing `manifest.json`).
5. Open a new tab and accept Chrome's new-tab change if prompted.

No Node.js, .NET, development server, or companion installation is needed for the dashboard and browser media mode. This package contains no personal settings or account credentials.

Keep the extracted folder: Chrome reads the extension from that location. To update, replace its contents with the new release, then click **Reload** at `chrome://extensions`. Moving or removing an unpacked extension can change its ID and local data. Use **Settings → Data → Export settings** before reinstalling or switching computers; import the saved JSON on the destination. Settings export currently includes preferences, favorites, groups, and custom wallpaper; widget content and Google sign-in must be set up again.

## Music without the companion

1. In the Music widget, click **Enable browser media** and allow Chrome's site-access request. Access lets PikaNav read player metadata and control audio/video in your open web tabs. You can remove this access in the extension's details at any time.
2. Start playback in a Chrome tab, then return to PikaNav.
3. The widget displays **Chrome tab** with the site's name. Play/pause works for accessible HTML audio/video players. Previous/next are enabled only when a supported site's track buttons are available (YouTube, YouTube Music, Spotify web, and SoundCloud).

The widget prefers a playing browser session, then a paused session. Browser media works only in this Chrome profile. Restricted Chrome pages, other browsers, desktop applications, inaccessible embedded players, shadow-DOM-only players, and players that do not expose an HTML audio/video element are not supported by browser mode. Sites can change their controls; unavailable track buttons stay disabled. Start playback in the site's own tab first if autoplay is blocked.

## Optional Windows companion

Windows desktop media (for example, the Spotify desktop app) and CPU/RAM/disk widgets still need the native companion. If no browser player is found, PikaNav tries the registered companion automatically. The portable ZIP deliberately contains only the Chrome extension.

Developers can install the companion from the source project's `pikanav-media-mvp/scripts/install-companion.ps1`, using this dashboard's extension ID. The existing installer requires Windows 10/11 and the .NET 8 SDK; its framework-dependent host also needs the .NET 8 runtime. See the source project's companion README. The companion is not required for normal dashboard use.

## Google Calendar

Calendar sign-in also depends on Google OAuth configuration. The configured Chrome-extension OAuth client must allow the installed extension ID. An unpacked extension loaded from a different folder or computer may have a different ID, so Google Calendar sign-in is not guaranteed by this portable package. Other dashboard features work independently of Google sign-in.

## Distribution

This ZIP installs through **Load unpacked** with Developer mode. It is not a one-click Chrome Web Store installation. For public one-click installation, publish the extension through the Chrome Web Store and configure its Google OAuth client for that store extension ID.

## Remove PikaNav

Use **Remove** at `chrome://extensions`, then delete the extracted folder if it is no longer needed. Export settings first if you want to keep them.
